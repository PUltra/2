﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UltraMatrixPolynominal;
using System.Numerics;

namespace Ultra_Console
{
    class Program
    {
        static void Main(string[] args)
        {

            //Creación de nueva matriz y polinomio
            /************************************************************
            Matrix c = new Matrix(new Double[3, 3] { { 3, 5, 8 }, { 3, 5, 7 }, { -1, 3, 1 } });
            Polynominal p = new Polynominal(new Double[4] { -3, -3, 3, 1 });
            */

            //Cada vez que queremos imprimir matriz o polinominal en la consola, simplemente llamamos al método Print:
            /*
            c.Print();
            p.Print();
            */

            //Operaciones de matriz
            #region

            /*
             // nueva matriz desde arreglo
            Matrix c = new Matrix(new Double[3, 3] { { 1, 2, 7 }, { 3, 4, 1 }, { -1, 3, 1 } });

            // nueva matriz con 3 filas, 3 columnas, todos los elementos equivalen a 10
            Matrix c1 = new Matrix(3, 3, 10);

            // nueva matriz 3 x 3, todos los valores diagonales son iguales a 1
            Matrix c2 = new Matrix(3, 1);

            Matrix result;

            // transposición de matriz
            result = c.Transpose();

            // escala de matriz
            result = c.Scale(10);

            // multiplicar por matriz
            result = c.Multiply(new Matrix(new Double[3, 3] { { 12, 12, 17 }, { -3, -4, -1 }, { 0, 0, 1 } }));

            // Matriz inversa
            result = c.Inverse();

            // add, sub matrix
            result = c.Add(new Matrix(new Double[3, 3] { { 12, 12, 17 }, { -3, -4, -1 }, { 0, 0, 1 } }));
            result = c.Sub(new Matrix(new Double[3, 3] { { 12, 12, 17 }, { -3, -4, -1 }, { 0, 0, 1 } }));

            // obtener rango de matriz
            int rank = c.Rank();

            // obtener determinante
            Double det = c.Determinant();

            // característica polinominal
            Polynominal cp = c.CharacteristicPolynominal();

            // Obtener elemento de matriz
            Double el = c.Element(1, 1);

            // Establecer elemento de matriz
            c.SetElement(1, 1, el);
            */
            #endregion

            //Operaciones de Polinomio
            #region
            // new polynominal from array (Double or Complex)
            Polynominal p = new Polynominal(new Double[4] { -3, -3, 3, 1 });
            Polynominal p1 = new Polynominal(new Double[4] { 1, 2, 3, 4 });

            Polynominal result;

            // add, sub polynominals
            result = p.Add(p1);
            result = p.Sub(p1);

            // polynominal derivative
            result = p.Derivative();

            // calculate division by binominal (x - 10)
            result = p.ByBinominalDivision(10);

            // evaluate with value 10
            Complex value = p.Evaluate(10);

            // get degree
            int degree = p.Degree();

            // scale with value 4
            result = p.Scale(4);

            // get element on position 2
            Complex el = p.Element(2);

            // set element on position 2
            p.SetElement(2, el);

            // calculate roots with seed 2 and accuracy 0.0001
            Complex[] x = p.Roots(2, 0.0001);
            #endregion

            
        }
    }
}
